<?php

include "PaymentGateway.php";
include "RefundGateway.php";

class Paypal implements PaymentGateway, RefundGateway
{
    public function processPayment(float $amount) : bool
    {
        echo "Processing a payment of " . "$" . "{$amount} via Paypal";
        return true;
    }
    public function processRefund(float $amount) : bool
    {
        echo "Processing a Refund of " . "$" . "{$amount} via Paypal";
        return true;
    }
}

// $paypal1 = new Paypal();
// $paypal1->processPayment(200.5);  // Processing a payment of $200.5 via Paypal
// echo "<br>";
// $paypal1->processRefund(20); // Processing a Refund of $20 via Paypal

