<?php

// include "Stripe.php";
// include "Xoom.php";
// include "Paypal.php";


class PaymentProcessor
{
    private PaymentGateway $gateway;
    public function __construct(PaymentGateway $gateway)
    {
        $this->gateway = $gateway;
    }
    public function process($amount)
    {
        $this->gateway->processPayment($amount);
    }
}

// $stripe = new Stripe();
// $stripeProcessor = new PaymentProcessor($stripe);
// $stripeProcessor->process(999.9);


// $xoom = new Xoom();
// $xoomProcessor = new PaymentProcessor($xoom);
// $xoomProcessor->process(555.5);


// $paypal = new Paypal();
// $paypalProcessor = new PaymentProcessor($paypal);
// $paypalProcessor->process(333);
