<?php

include "PaymentGateway.php";

class Stripe implements PaymentGateway
{
    public function processPayment(float $amount) : bool
    {
        echo "Processing a payment of " . "$" . "{$amount} via Stripe";
        return true;
    }
}

// $stripe = new Stripe();
// echo $stripe->processPayment(100.5);

