<?php

include "PaymentGateway.php";

class Xoom implements PaymentGateway
{
    public function processPayment(float $amount) : bool
    {
        echo "Processing a payment of " . "$" . "{$amount} via Xoom";
        return true;
    }
}

// $xoom = new Xoom();
// echo $xoom->processPayment(400.5);

