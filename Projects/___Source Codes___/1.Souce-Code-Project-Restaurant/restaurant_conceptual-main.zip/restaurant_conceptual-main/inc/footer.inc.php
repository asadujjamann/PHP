 </main>

 <footer>
     <p>Leade Educare's website.</p>
 </footer>
 </body>

 </html>